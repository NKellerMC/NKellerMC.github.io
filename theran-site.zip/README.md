# THERAN — site oficial

Site em React, TypeScript e Vite, publicado no GitHub Pages.

## Desenvolvimento

```bash
npm install
npm run dev
```

## Verificação e build

```bash
npm run typecheck
npm run build
```

O resultado pronto para publicação é gerado em `dist/`.

## Estrutura

- `src/app/`: navegação, carregamento de rotas e ciclo de vida da interface.
- `src/content/pages/`: conteúdo e estilos preservados de cada página, em português e inglês.
- `assets/js/`: módulos interativos do oceano, celular, Ariq, Orin, Threadly, lojas e leitor.
- `assets/`: imagens, ícones, estilos e arquivos do livro.

## Publicação

Um envio para a branch `main` executa o build e publica `dist/` automaticamente. Na primeira configuração do repositório, selecione **GitHub Actions** em **Settings → Pages → Source**.
