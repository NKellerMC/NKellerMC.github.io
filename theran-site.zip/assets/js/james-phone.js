window.THERAN=window.THERAN||{};
window.THERAN.cleanups=window.THERAN.cleanups||{};

window.THERAN.mountJamesPhone=()=>{
  window.THERAN.cleanups.jamesPhone?.();
  'use strict';

  const root=document.querySelector('#jamesDevice');
  if(!root)return()=>{};

  const controller=new AbortController();
  const {signal}=controller;
  const EN=document.documentElement.lang.toLowerCase().startsWith('en');
  const $=(selector)=>root.querySelector(selector);
  const $$=(selector)=>[...root.querySelectorAll(selector)];
  const views=$$('[data-phone-view]');

  const copy=EN?{
    date:new Intl.DateTimeFormat('en-US',{weekday:'long',month:'short',day:'numeric'}),
    personal:'personal conversation',pinnedLabel:'pinned',
    all:'All',pinned:'Pinned',unread:'Unread',
    none:'No conversations found.',
    local:'Created only in this preview.',
    sendPlaceholder:'Write a message'
  }:{
    date:new Intl.DateTimeFormat('pt-BR',{weekday:'long',day:'numeric',month:'short'}),
    personal:'conversa pessoal',pinnedLabel:'fixada',
    all:'Tudo',pinned:'Fixados',unread:'Não lidas',
    none:'Nenhuma conversa encontrada.',
    local:'Criada somente nesta prévia.',
    sendPlaceholder:'Escrever mensagem'
  };

  const threads=EN?[
    {id:'noah',name:'Noah',initial:'N',pinned:true,unread:0,time:'23:05',preview:'Liar.',messages:[
      {day:'After the broadcast'},
      {dir:'in',attachment:{title:'BROADCAST MAP',meta:'central region circled'},text:'I’ve been staring at this for ten minutes and maybe I’m very stupid, but the currents shouldn’t point into the middle of a continent.',time:'21:08'},
      {dir:'out',text:'It isn’t the water flowing in. Look at the lines on the map: if you follow their direction, they all lead into Mora.',time:'21:09'},
      {dir:'in',text:'I know. That’s what I’m saying.',time:'21:09'},
      {dir:'in',text:'I was hoping you’d have a better explanation.',time:'21:10'},
      {dir:'out',text:'Why would I?',time:'21:10'},
      {dir:'in',text:'You spent almost a week staring at a stopped ship. I thought you might have unlocked some ability.',time:'21:11'},
      {dir:'out',text:'Unfortunately, no.',time:'21:12'},
      {day:'Later that night'},
      {dir:'in',text:'Are you still looking at that map?',time:'23:04'},
      {dir:'out',text:'No.',time:'23:05'},
      {dir:'in',text:'Liar.',time:'23:05'}
    ]},
    {id:'sarah',name:'Sarah',initial:'S',pinned:true,unread:1,time:'23:44',preview:'damn',messages:[
      {day:'During the break'},
      {dir:'in',attachment:{title:'CAFETERIA TV',meta:'CONFIRMED CASES: 31'},time:'11:26'},
      {day:'After the historical catalog'},
      {dir:'in',text:'you owe me 5 credits',time:'23:43'},
      {dir:'out',text:'you bet I WOULDN’T look it up',time:'23:43'},
      {dir:'in',text:'damn',time:'23:44'}
    ]},
    {id:'mother',name:'Mother',initial:'M',pinned:false,unread:0,time:'16:02',preview:'There’s food in the pot. I’ll be back at six.',messages:[
      {day:'Yesterday'},
      {dir:'in',text:'There’s food in the pot. I’ll be back at six.',time:'16:02'}
    ]}
  ]:[
    {id:'noah',name:'Noah',initial:'N',pinned:true,unread:0,time:'23:05',preview:'Mentiroso.',messages:[
      {day:'Depois da reportagem'},
      {dir:'in',attachment:{title:'MAPA DA REPORTAGEM',meta:'região central circulada'},text:'Eu tô olhando isso faz dez minutos e talvez eu seja muito burro, mas as correntes não deviam apontar pro meio de um continente.',time:'21:08'},
      {dir:'out',text:'Não é a água entrando lá. Olha as linhas do mapa: se você seguir a direção delas, todas vão dar dentro de Mora.',time:'21:09'},
      {dir:'in',text:'Eu sei. É isso que eu tô falando.',time:'21:09'},
      {dir:'in',text:'Eu tava esperando você ter uma explicação melhor.',time:'21:10'},
      {dir:'out',text:'Por que eu teria?',time:'21:10'},
      {dir:'in',text:'Você passou quase uma semana olhando pra navio parado. Achei que tivesse desbloqueado alguma habilidade.',time:'21:11'},
      {dir:'out',text:'Infelizmente, não.',time:'21:12'},
      {day:'Mais tarde naquela noite'},
      {dir:'in',text:'Você ainda tá olhando aquele mapa?',time:'23:04'},
      {dir:'out',text:'Não.',time:'23:05'},
      {dir:'in',text:'Mentiroso.',time:'23:05'}
    ]},
    {id:'sarah',name:'Sarah',initial:'S',pinned:true,unread:1,time:'23:44',preview:'droga',messages:[
      {day:'Durante o intervalo'},
      {dir:'in',attachment:{title:'TV DA CANTINA',meta:'CASOS CONFIRMADOS: 31'},time:'11:26'},
      {day:'Depois do catálogo histórico'},
      {dir:'in',text:'você me deve 5 créditos',time:'23:43'},
      {dir:'out',text:'você apostou que NÃO ia pesquisar',time:'23:43'},
      {dir:'in',text:'droga',time:'23:44'}
    ]},
    {id:'mother',name:'Mãe',initial:'M',pinned:false,unread:0,time:'16:02',preview:'Tem comida na panela. Volto às seis.',messages:[
      {day:'Ontem'},
      {dir:'in',text:'Tem comida na panela. Volto às seis.',time:'16:02'}
    ]}
  ];

  const stories=EN?[
    {id:'james',name:'James',avatar:'JC',time:'now',kicker:'confirmed cases',text:'31 ships. Yesterday there were 24.',image:'assets/media/threadly/stories/james.webp'},
    {id:'sarah',name:'Sarah',avatar:'SA',time:'4 min',kicker:'cafeteria',text:'The screen says 31 confirmed cases. Seven more since yesterday.',image:'assets/media/threadly/stories/sarah.webp'},
    {id:'halvern',name:'Halvern Pulse',avatar:'HP',time:'12 min',kicker:'maritime events',text:'Cases have been reclassified as non-integrated. Authorities report no immediate risk.',image:'assets/media/threadly/stories/pulso-halvern.webp'},
    {id:'dt',name:'Distant Trees',avatar:'DT',time:'31 min',kicker:'seasonal inspection',text:'Seasonal inspections of school units continue today.',image:'assets/media/threadly/stories/distant-trees.webp'},
    {id:'orla',name:'Shore 7',avatar:'S7',time:'48 min',kicker:'port update',text:'Some ports are holding cargo departures while the cause remains unknown.',image:'assets/media/threadly/stories/orla-7.webp'}
  ]:[
    {id:'james',name:'James',avatar:'JC',time:'agora',kicker:'casos confirmados',text:'31 navios. Ontem eram 24.',image:'assets/media/threadly/stories/james.webp'},
    {id:'sarah',name:'Sarah',avatar:'SA',time:'4 min',kicker:'cantina',text:'A tela diz 31 casos confirmados. Sete a mais desde ontem.',image:'assets/media/threadly/stories/sarah.webp'},
    {id:'halvern',name:'Pulso Halvern',avatar:'PH',time:'12 min',kicker:'eventos marítimos',text:'Os casos foram reclassificados como não-integrados. Autoridades afirmam que não há risco imediato.',image:'assets/media/threadly/stories/pulso-halvern.webp'},
    {id:'dt',name:'Distant Trees',avatar:'DT',time:'31 min',kicker:'inspeção sazonal',text:'As inspeções sazonais das unidades escolares continuam hoje.',image:'assets/media/threadly/stories/distant-trees.webp'},
    {id:'orla',name:'Orla 7',avatar:'O7',time:'48 min',kicker:'atualização portuária',text:'Alguns portos estão segurando a saída de cargueiros enquanto a causa continua desconhecida.',image:'assets/media/threadly/stories/orla-7.webp'}
  ];

  let activeView='home';
  let currentThread='noah';
  let filter='all';
  let query='';
  let storyIndex=0;
  let storyImageToken=0;

  function escapeHTML(value){return String(value??'').replace(/[&<>'"]/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[char]))}

  function updateClock(){
    const now=new Date();
    const time=$('#phoneClock');
    const compact=$('#phoneSystemTime');
    const date=$('#phoneDate');
    const formatted=now.toLocaleTimeString(EN?'en-US':'pt-BR',{hour:'2-digit',minute:'2-digit',hour12:false});
    if(time)time.textContent=formatted;
    if(compact)compact.textContent=formatted;
    if(date)date.textContent=copy.date.format(now);
  }

  function openView(name){
    if(!views.some(view=>view.dataset.phoneView===name))return;
    if(name!=='threadly')closeStory();
    activeView=name;
    root.dataset.activeApp=name;
    views.forEach(view=>view.classList.toggle('is-active',view.dataset.phoneView===name));
    if(name==='orin')requestAnimationFrame(()=>window.dispatchEvent(new Event('resize')));
  }

  function showToast(message){
    const toast=$('#phoneToast');
    if(!toast)return;
    toast.textContent=message;
    toast.classList.add('show');
    clearTimeout(showToast.timer);
    showToast.timer=setTimeout(()=>toast.classList.remove('show'),1700);
  }

  function closeStory(){
    const viewer=$('#threadlyStoryViewer');
    if(!viewer)return;
    storyImageToken++;
    viewer.hidden=true;
    viewer.setAttribute('aria-hidden','true');
  }

  function renderStory(index){
    const viewer=$('#threadlyStoryViewer');
    const stage=$('#threadlyStoryStage');
    if(!viewer||!stage||!stories.length)return;
    storyIndex=(index+stories.length)%stories.length;
    const story=stories[storyIndex];
    viewer.hidden=false;
    viewer.setAttribute('aria-hidden','false');
    viewer.dataset.theme=story.id;
    $('#threadlyStoryAvatar').textContent=story.avatar;
    $('#threadlyStoryName').textContent=story.name;
    $('#threadlyStoryTime').textContent=story.time;
    $('#threadlyStoryKicker').textContent=story.kicker;
    $('#threadlyStoryText').textContent=story.text;
    $('#threadlyStoryProgress').innerHTML=stories.map((_,itemIndex)=>`<span class="${itemIndex<storyIndex?'done':itemIndex===storyIndex?'active':''}"></span>`).join('');
    $$(`[data-threadly-story="${story.id}"]`).forEach(button=>button.classList.add('is-seen'));
    stage.style.backgroundImage='';
    const token=++storyImageToken;
    const image=new Image();
    image.addEventListener('load',()=>{if(token===storyImageToken&&!viewer.hidden)stage.style.backgroundImage=`url("${story.image}")`},{once:true});
    image.src=story.image;
  }

  function filteredThreads(){
    return threads.filter(thread=>{
      const matchesFilter=filter==='all'||(filter==='pinned'&&thread.pinned)||(filter==='unread'&&thread.unread);
      const matchesQuery=!query||`${thread.name} ${thread.preview}`.toLowerCase().includes(query);
      return matchesFilter&&matchesQuery;
    });
  }

  function renderThreadList(){
    const list=$('#ariqThreadList');
    if(!list)return;
    const items=filteredThreads();
    list.innerHTML=items.length?items.map(thread=>`<button class="ariq-thread" data-thread-id="${thread.id}" type="button"><span class="ariq-thread-avatar">${escapeHTML(thread.initial)}</span><span class="ariq-thread-copy"><span class="ariq-thread-name">${escapeHTML(thread.name)}${thread.pinned?` <span aria-label="${copy.pinnedLabel}">◇</span>`:''}</span><span class="ariq-thread-preview">${escapeHTML(thread.preview)}</span></span><span class="ariq-thread-side"><span class="ariq-thread-time">${escapeHTML(thread.time)}</span>${thread.unread?`<span class="ariq-badge">${thread.unread}</span>`:''}</span></button>`).join(''):`<div class="ariq-empty">${copy.none}</div>`;
    list.querySelectorAll('[data-thread-id]').forEach(button=>button.addEventListener('click',()=>openThread(button.dataset.threadId),{signal}));
  }

  function renderMessages(){
    const thread=threads.find(item=>item.id===currentThread)||threads[0];
    const pane=$('#ariqMessages');
    if(!thread||!pane)return;
    $('#ariqChatAvatar').textContent=thread.initial;
    $('#ariqChatName').textContent=thread.name;
    $('#ariqChatSubtitle').textContent=copy.personal;
    pane.innerHTML=thread.messages.map(message=>{
      if(message.day)return`<div class="ariq-day">${escapeHTML(message.day)}</div>`;
      const attachment=message.attachment?`<div class="ariq-attachment"><strong>${escapeHTML(message.attachment.title)}</strong><span>${escapeHTML(message.attachment.meta)}</span></div>`:'';
      const bubble=message.text?`<div class="ariq-bubble">${escapeHTML(message.text)}</div>`:'';
      return`<div class="ariq-msg-row ${message.dir==='out'?'out':'in'}"><div class="ariq-msg-block">${message.sender?`<div class="ariq-sender">${escapeHTML(message.sender)}</div>`:''}${attachment}${bubble}<div class="ariq-msg-meta">${escapeHTML(message.time)}</div></div></div>`;
    }).join('');
    requestAnimationFrame(()=>{pane.scrollTop=pane.scrollHeight});
  }

  function openThread(id){
    currentThread=id;
    const thread=threads.find(item=>item.id===id);
    if(thread)thread.unread=0;
    renderThreadList();
    renderMessages();
    $('#ariqShell')?.classList.add('chat-open');
  }

  function closeThread(){$('#ariqShell')?.classList.remove('chat-open')}

  function sendMessage(){
    const input=$('#ariqComposer');
    const value=input?.value.trim();
    if(!value)return;
    const thread=threads.find(item=>item.id===currentThread);
    if(!thread)return;
    const now=new Date().toLocaleTimeString(EN?'en-US':'pt-BR',{hour:'2-digit',minute:'2-digit',hour12:false});
    thread.messages.push({dir:'out',text:value,time:now});
    thread.preview=value;
    thread.time=now;
    input.value='';
    renderMessages();
    renderThreadList();
    showToast(copy.local);
  }

  $$('[data-phone-open]').forEach(button=>button.addEventListener('click',()=>openView(button.dataset.phoneOpen),{signal}));
  $$('[data-phone-home]').forEach(button=>button.addEventListener('click',()=>{closeThread();openView('home')},{signal}));
  $('#ariqBack')?.addEventListener('click',closeThread,{signal});
  $('#ariqSearchInput')?.addEventListener('input',event=>{query=event.target.value.trim().toLowerCase();renderThreadList()},{signal});
  $('#ariqClearSearch')?.addEventListener('click',()=>{const input=$('#ariqSearchInput');if(input){input.value='';input.focus()}query='';renderThreadList()},{signal});
  $$('.ariq-filter').forEach(button=>button.addEventListener('click',()=>{filter=button.dataset.filter;$$('.ariq-filter').forEach(item=>item.classList.toggle('active',item===button));renderThreadList()},{signal}));
  $('#ariqSend')?.addEventListener('click',sendMessage,{signal});
  $('#ariqComposer')?.addEventListener('keydown',event=>{if(event.key==='Enter'&&!event.shiftKey){event.preventDefault();sendMessage()}},{signal});
  $$('[data-threadly-like]').forEach(button=>button.addEventListener('click',()=>{button.classList.toggle('is-liked');button.setAttribute('aria-pressed',String(button.classList.contains('is-liked')));const count=Number(button.dataset.count||0)+(button.classList.contains('is-liked')?1:0);const label=button.querySelector('[data-threadly-count]');if(label)label.textContent=String(count)},{signal}));
  $$('.threadly-tabs button').forEach(button=>button.addEventListener('click',()=>{$$('.threadly-tabs button').forEach(item=>item.classList.toggle('active',item===button))},{signal}));
  $$('[data-threadly-story]').forEach(button=>button.addEventListener('click',()=>{const index=stories.findIndex(story=>story.id===button.dataset.threadlyStory);renderStory(index<0?0:index)},{signal}));
  $('#threadlyStoryClose')?.addEventListener('click',closeStory,{signal});
  $('#threadlyStoryPrev')?.addEventListener('click',()=>renderStory(storyIndex-1),{signal});
  $('#threadlyStoryNext')?.addEventListener('click',()=>renderStory(storyIndex+1),{signal});
  document.addEventListener('keydown',event=>{if(event.key==='Escape')closeStory()},{signal});

  const noteCards=$$('[data-note-card]');
  const notesSearchInput=$('#notesSearchInput');
  const filterNotes=()=>{
    const query=String(notesSearchInput?.value||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').trim().toLowerCase();
    let visible=0;
    noteCards.forEach(card=>{
      const haystack=String(card.dataset.noteSearch||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
      const match=!query||haystack.includes(query);
      card.hidden=!match;
      if(match)visible++;
    });
    const empty=$('#notesEmpty');
    if(empty)empty.hidden=visible>0;
  };
  $$('[data-note-toggle]').forEach(button=>button.addEventListener('click',()=>{
    const card=button.closest('[data-note-card]');
    const open=!card?.classList.contains('is-open');
    card?.classList.toggle('is-open',open);
    button.setAttribute('aria-expanded',String(open));
  },{signal}));
  notesSearchInput?.addEventListener('input',filterNotes,{signal});
  $('#notesSearchClear')?.addEventListener('click',()=>{if(notesSearchInput){notesSearchInput.value='';notesSearchInput.focus()}filterNotes()},{signal});

  updateClock();
  const clockTimer=setInterval(updateClock,30000);
  renderThreadList();
  openView('home');

  const cleanup=()=>{controller.abort();clearInterval(clockTimer);clearTimeout(showToast.timer)};
  window.THERAN.cleanups.jamesPhone=cleanup;
  return cleanup;
};

window.THERAN.mountJamesPhone();
